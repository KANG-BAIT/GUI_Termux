clear
echo "\033[5;31m"
echo ""
echo "             █░▄▀ █▀▀█ █▀▀▄ █▀▀▀   █▀▀█ █▀▀█ ▀█▀ ▀▀█▀▀        "
echo "             █▀▄░ █▄▄█ █░░█ █░▀█   █▀▀▄ █▄▄█ ░█░ ░▒█░░        "
echo "             █░▒█ ▀░░▀ ▀░░▀ ▀▀▀▀   █▄▄█ ▀░░▀ ▄█▄ ░▒█░░        "
printf '\033[1;33m'
echo "  ─────────────╔╗─╔╗──────────  ───╔═╗──────  ╔╗────╔╗──────╔═╗─────────"""
echo "  ╔═╗╔╦╗╔═╗─╔═╗║╚╗╠╣╔═╗╔═╗─╔╗─  ╔╦╗║═╣╔═╗╔╦╗  ╠╣╔═╦╗║╚╗╔═╗╔╦╗║═╣╔═╗─╔═╗╔═╗"""
echo "  ║╬║║╔╝║╬╚╗║╬║║║║║║║═╣║╬╚╗║╚╗  ║║║╠═║║╩╣║╔╝  ║║║║║║║╔╣║╩╣║╔╝║╔╝║╬╚╗║═╣║╩╣"""
echo "  ╠╗║╚╝─╚══╝║╔╝╚╩╝╚╝╚═╝╚══╝╚═╝  ╚═╝╚═╝╚═╝╚╝─  ╚╝╚╩═╝╚═╝╚═╝╚╝─╚╝─╚══╝╚═╝╚═╝"""
echo "  ╚═╝───────╚╝────────────────  ────────────  ────────────────────────────"""
echo ""
echo ""
echo "\033[5;32m"
echo "start.........."
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
vncserver -localhost
printf "\033[32;1m masukan password vnc server"
export DISPLAY=":1"
~/.vnc/xstartup
#! / data / data / com.termux /files / usr / bin / sh 
## Desktop Fluxbox. 


# Hasilkan menu. fluxbox-generate_menu 

# Mulai fluxbox. 
fluxbox &

~/.vnc/xstartup

#! / data / data / com.termux / files / usr / bin / sh

# Mulai Openbox. 
openbox-sesi &

~/.vnc/xstartup

${PREFIX}/etc/xdg/openbox/autostart

~/.config/openbox/autostart


# Luncurkan PyPanel. 
pypanel &


~/.vnc/xstartup

xfce4-session &

sh Selesai.sh