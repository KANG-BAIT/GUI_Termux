clear

neofetch


echo "\033[5;32mStatus Runing....'date'"